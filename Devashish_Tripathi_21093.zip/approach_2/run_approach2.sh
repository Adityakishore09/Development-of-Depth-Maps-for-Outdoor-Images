# Runs the training code in exp_2.py. Please make changes in the code accordingly
python exp_2.py
