# Runs the training code in first.py
python first.py
# Runs the inference code. Please make changes in both the codes for the relevant paths accordingly
python infer.py